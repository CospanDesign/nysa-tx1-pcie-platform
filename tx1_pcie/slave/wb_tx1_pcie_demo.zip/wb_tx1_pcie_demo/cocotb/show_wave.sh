#! /bin/bash

gtkwave la.gtkw &
